import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {levels,chapters,evaluate,nextHint} from '../dist/engine.mjs';
import {earnedHeadwear,canWear} from '../dist/avatars.mjs';
import {validateBackup} from '../dist/backup.mjs';
import {chapterSummary,drawChapterCard} from '../dist/chapter-card.mjs';
import {translator} from '../dist/i18n.mjs';
import {existsSync} from 'node:fs';
assert.equal(createHash('sha256').update(JSON.stringify(levels.slice(0,60))).digest('hex'),'2ba64531a5303b7d1bb46974571919c05b170c3f5429859d34d3f23c2acbe764','Prior 60 levels stay identical');
const fresh=levels.slice(60,72);assert.equal(levels.length,96);assert.equal(fresh.length,12);assert.equal(chapters[5].id,'stellar');assert(existsSync(new URL('../dist/characters/hat-stellar.png',import.meta.url)));
const distinct=new Set(levels.slice(0,60).map(l=>JSON.stringify(l.paths)));
for(const l of fresh){
 assert.equal(l.n,l.id<63?5:6);assert.deepEqual(l.paths.map(p=>p.color),l.id===63||l.id===64?['mint','amber']:['mint','amber','violet']);assert(!distinct.has(JSON.stringify(l.paths)));distinct.add(JSON.stringify(l.paths));
 assert(!evaluate(l,l.initial).solved);const state=evaluate(l,Array(l.n*l.n).fill(0));assert(state.solved);
 const endpoints=l.paths.flatMap(p=>[p.cells[0],p.cells.at(-1)]);assert.equal(new Set(endpoints).size,l.paths.length*2);
 for(const path of l.paths)for(const cell of path.cells){const group=l.tiles[cell].groups.findIndex((_,g)=>state.lit[cell][g].has(path.color));assert(group>=0);assert.equal(state.lit[cell][group].size,1,'No colour leakage in authored solution');}
 assert.equal(!!l.gate,l.id>=67);assert.equal(l.frozen!==undefined,l.id>=71);
 if(l.gate){assert(!l.paths[1].cells.includes(l.gate.tile),'Amber never depends on the gate it opens');assert(l.paths[0].cells.includes(l.gate.tile));}
 for(let seed=0;seed<40;seed++){
  let random=(seed+1)*2654435761;const r=l.tiles.map(()=>{random^=random<<13;random^=random>>>17;random^=random<<5;return (random>>>0)%4;});
  if(l.frozen!==undefined)r[l.frozen]=1;
  for(let step=0;step<100&&!evaluate(l,r).solved;step++){
   const h=nextHint(l,r);assert(h);assert(h.tile!==l.frozen||evaluate(l,r).open,'Hint cannot rotate a locked tile');r[h.tile]=h.rotation;
  }
  assert(evaluate(l,r).solved,`Legal hint convergence on ${l.id}/${seed}`);
 }
}
assert(fresh.at(-1).paths.reduce((n,p)=>n+p.cells.length,0)>fresh[0].paths.reduce((n,p)=>n+p.cells.length,0));
const old={version:1,lang:'en',completed:Array.from({length:60},(_,i)=>i+1),records:{60:{time:5000,moves:12}},last:60,sound:false,ambience:false,haptics:false,showTime:true,hintBalance:24,hintBaseUsed:{}};
const profile={id:'p',name:'Ada',symbol:5,hat:'aurora',data:old};const backup={format:'sporlys-backup',version:1,activeProfile:'p',profiles:[profile]};assert.deepEqual(validateBackup(backup,72).profiles[0],profile);assert.equal(earnedHeadwear(old).length,5);assert(!canWear(old,'stellar'));assert.throws(()=>chapterSummary(profile,old,chapters[5]));
const full=structuredClone(old);full.completed.push(...fresh.map(l=>l.id));full.last=72;assert(canWear(full,'stellar'));profile.hat='stellar';profile.data=full;assert.deepEqual(validateBackup(backup,72).profiles[0],profile);
const summary=chapterSummary(profile,full,chapters[5]);assert.equal(summary.chapterName,'Star depths');assert.equal(summary.hats,6);assert.equal(summary.count,12);assert.equal(summary.hints,24);
const images=[],texts=[];const ctx=new Proxy({createLinearGradient:()=>({addColorStop(){}}),createRadialGradient:()=>({addColorStop(){}}),measureText:t=>({width:t.length*10}),drawImage:i=>images.push(i),fillText:t=>texts.push(t)},{get:(o,k)=>k in o?o[k]:()=>{}});const canvas={getContext:()=>ctx};await drawChapterCard(summary,{canvas,loadImage:async src=>src});assert(images.includes('characters/hat-stellar.png'));assert(texts.includes('Levels 61–72'));assert(texts.includes('Star depths complete!'));assert(texts.includes('6'));
for(const lang of ['nb','en']){const t=translator(lang);for(const key of ['stellarChapter','stellarSeries','hat_stellar'])assert.notEqual(t(key),key);}
console.log('PASS: 12 new 5x5/6x6 layouts, three isolated colours, staged gates/frost, legal hints on 480 scrambles, old progress, six prizes, backup and Star depths card.');
// Existing 60-level completion opens 61, rather than replaying 48 or losing records.
const events={},root={innerHTML:'',classList:{toggle(){}}},modal={innerHTML:'',open:false,showModal(){this.open=true},close(){this.open=false},addEventListener(){}};let stored=JSON.stringify({...old,profiles:[{...profile,hat:'aurora',data:old}],activeProfile:'p'});
globalThis.document={hidden:false,documentElement:{lang:'en'},querySelector:s=>s==='#app'?root:s==='#modal'?modal:s==='.world-lights'?{innerHTML:''}:null,addEventListener:(k,f)=>events[k]=f};Object.defineProperty(globalThis,'navigator',{value:{language:'en'},configurable:true});globalThis.localStorage={getItem:()=>stored,setItem:(_,v)=>stored=v};globalThis.setInterval=()=>{};
const click=dataset=>events.click({target:{closest:()=>({dataset,disabled:false})}});await import('../dist/app.mjs?aurora');assert(root.innerHTML.includes('<small>Level 61</small>'));click({action:'levels'});assert(root.innerHTML.includes('Star depths'));assert(root.innerHTML.includes('data-level="61"'));assert(!root.innerHTML.includes('data-action="chapterCard"'));click({action:'start'});assert(root.innerHTML.includes('Star depths'));assert.equal(JSON.parse(stored).hintBalance,15);assert.deepEqual(JSON.parse(stored).records,old.records);assert.equal(JSON.parse(stored).profiles[0].hat,'aurora');
console.log('PASS: old 60-level player continues at 61 with records, hint bank and equipment preserved.');

const large={...old,completed:[...old.completed,61,62],last:63};stored=JSON.stringify({...large,profiles:[{...profile,hat:'aurora',data:large}],activeProfile:'p'});await import('../dist/app.mjs?stellar-large');click({action:'start'});assert(root.innerHTML.includes('size-6'));assert.equal((root.innerHTML.match(/data-rotate=/g)||[]).length,36);assert(root.innerHTML.includes('Larger board, same rules'));
console.log('PASS: 6x6 renders 36 tiles with a localized two-colour introduction.');
